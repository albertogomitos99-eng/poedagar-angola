module.exports = {
  images: {
    domains: ["ae01.alicdn.com", "aliexpress.com"],
  },
};